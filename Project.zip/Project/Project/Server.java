import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

public class Server implements Ticket{

	try{
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ticketing_system?user=root&password=pass");


	ResultSet rs = null;
	PreparedStatement pst = null;
	Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);

	public String getName(){
	rs = stmt.executeQuery(Select eventName FROM event);
	return rs;
	}
	public int getTicketSold(){
	rs = stmt.executeQuery(Select soldTickets FROM event);
	return rs;
	}
	public int getNumberAvailable(){
	rs = stmt.executeQuery(Select (totalTickets-soldTickets) AS "Available Tickets" FROM event);
	return rs;
	}
	public void buyTicket(){
	pst = con.prepareStatement("Update customer set
	}
	public void returnTicket(){

	}
	public String getNotification(){

	}







	} catch(SQLException err){
		System.out.print(err.getMessage());
	}



	    public static void main(String[] args){
	    	try{
		    	Server obj = new Server();
		    	Ticket stub = (Ticket)UnicastRemoteObject.exportObject(obj,0);
		    	Registry registry = LocateRegistry.getRegistry();
		    	registry.rebind("ticket",stub);
	    	}catch(Exception e){
	    		e.printStackTrace();
	    	}
	    }
}

